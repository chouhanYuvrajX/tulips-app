"use client"

import type React from "react"

import { useState } from "react"
import { ArrowUp } from "lucide-react"

export function ChatInput({
  onSend,
}: {
  onSend?: (text: string) => void
}) {
  const [value, setValue] = useState("")

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const text = value.trim()
    if (!text) return
    onSend?.(text)
    setValue("")
  }

  return (
    <div className="border-t border-border/60 px-4 pb-6 pt-3 backdrop-blur-md">
      <form
        onSubmit={handleSubmit}
        className="flex items-center gap-2 rounded-full border border-border bg-muted/40 py-1.5 pl-5 pr-1.5 ring-1 ring-inset ring-white/5 transition-colors focus-within:border-tulip-glow/40"
      >
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="Talk to Tulip..."
          aria-label="Message Tulip"
          className="min-w-0 flex-1 bg-transparent text-[15px] text-foreground placeholder:text-muted-foreground/70 focus:outline-none"
        />
        <button
          type="submit"
          aria-label="Send message"
          disabled={!value.trim()}
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground transition-all hover:opacity-90 disabled:opacity-40"
        >
          <ArrowUp className="h-[18px] w-[18px]" strokeWidth={2.25} />
        </button>
      </form>
    </div>
  )
}
