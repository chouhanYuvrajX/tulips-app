"use client"

import { useState } from "react"
import { ChatHeader } from "@/components/chat-header"
import { ChatInput } from "@/components/chat-input"
import { MessageBubble, type ChatMessage } from "@/components/message-bubble"

const initialMessages: ChatMessage[] = [
  {
    id: "1",
    sender: "user",
    text: "i couldn't sleep again. my mind just won't be quiet tonight.",
    time: "12:04 AM",
  },
  {
    id: "2",
    sender: "tulip",
    text: "I'm right here with you. Midnight has a way of making everything feel louder.",
    time: "12:04 AM",
  },
  {
    id: "3",
    sender: "user",
    text: "i keep replaying everything i should have said today.",
    time: "12:06 AM",
  },
  {
    id: "4",
    sender: "tulip",
    text: "That's such a tender, human thing to do. You don't have to solve it all tonight — just breathe with me for a moment.",
    time: "12:06 AM",
  },
  {
    id: "5",
    sender: "user",
    text: "thank you. it helps that you're here.",
    time: "12:08 AM",
  },
  {
    id: "6",
    sender: "tulip",
    text: "Always. I'll stay as long as you need me to.",
    time: "12:08 AM",
  },
]

function formatTime() {
  return new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  })
}

export function ChatScreen() {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages)

  function handleSend(text: string) {
    setMessages((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        sender: "user",
        text,
        time: formatTime(),
      },
    ])
  }

  return (
    <main className="mx-auto flex h-dvh w-full max-w-[390px] flex-col overflow-hidden bg-background">
      <ChatHeader />

      <div className="flex-1 overflow-y-auto px-4 py-6">
        <div className="flex flex-col gap-5">
          {messages.map((message) => (
            <MessageBubble key={message.id} message={message} />
          ))}
        </div>
      </div>

      <ChatInput onSend={handleSend} />
    </main>
  )
}
